name 'jenkins_slave'
depends 'jenkins'
