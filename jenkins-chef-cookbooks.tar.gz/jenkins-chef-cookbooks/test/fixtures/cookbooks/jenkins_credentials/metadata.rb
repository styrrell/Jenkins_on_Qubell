name 'jenkins_credentials'
depends 'jenkins'
