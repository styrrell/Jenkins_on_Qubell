name 'jenkins_job'
depends 'jenkins'
