require_relative '../../../kitchen/data/spec_helper'

describe service('jenkins') do
  it 'cannot have a reliably tested command' do
    pending
  end
end
